package com.spring.example.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.spring.example.model.Investment;
import com.spring.example.model.InvestmentPage;
import com.spring.example.model.InvestmentSearchCriteria;
import com.spring.example.service.InvestmentService;

@RestController
public class InvestmentModuleController {

	@Autowired
	private InvestmentService investmentService;
	
	@Value("${upoadDir}")
	private String uploadFolder;
	
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@PostMapping("/AddInvestement")
	public @ResponseBody ResponseEntity<?>createInvestment(@RequestParam("investmentid") long investmentid,
			@RequestParam("purpose") String purpose,@RequestParam("amount") long amount,@RequestParam("payment_Method") long payment_Method,
			@RequestParam("currency") String currency,@RequestParam("") String company,@RequestParam("country") String country,
			@RequestParam("state") String state,@RequestParam("branch") String branch,@RequestParam("description") String description,
			Model model, HttpServletRequest request,final @RequestParam("invoice") MultipartFile invoicefile){
		
		try {
			String uploadDirectory=request.getServletContext().getRealPath(uploadFolder);
			log.info("uploadDirectory::"+uploadDirectory);
			byte[] invoiceData = invoicefile.getBytes();
			Investment investment = new Investment();
			investment.setInvestmentid(investmentid);
			investment.setAmount(amount);
			investment.setBranch(branch);
			investment.setCompany(company);
			investment.setCountry(country);
			investment.setCurrency(currency);
			investment.setDescription(description);
			investment.setInvoice(invoiceData);
			investment.setPayment_Method(payment_Method);
			investment.setPurpose(purpose);
			investment.setState(state);
			
			investmentService.save(investment);
			
			return new ResponseEntity<>("success",HttpStatus.OK);
	}
		catch (Exception e) {
			e.printStackTrace();
			log.info("Exception: " + e);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/listAllInv",method=RequestMethod.GET)
	public List<Investment> listAll()
	{
		if(investmentService.listAll()==null)
		{
			throw new NullPointerException("No Investment were found");
		}
		System.out.println("getting records");
		
		return investmentService.listAll();
	}
	
	@RequestMapping(value = "/deleteAllInv",method=RequestMethod.DELETE)
	public String deleteAll()
	{
		investmentService.delete();
		return "all records deleted successfully";
	}
	
	//get single Investment details
			@RequestMapping(value = "/getInvestment",method=RequestMethod.GET)
			public Investment getInvestment(@RequestParam long investmentid) {
				System.out.println("getting record!!!!");
				return investmentService.findByInvestmentid(investmentid)
					.orElseThrow(()-> new UsernameNotFoundException("Investemnt Does not exist wit the id   "+investmentid));
			}
			

			//delete single Investment details
			@DeleteMapping("/deleteInvestement")
			public ResponseEntity<?> delete(@RequestParam long investmentid) {
				Optional<Investment> details=investmentService.findByInvestmentid(investmentid);
				if(details.isPresent())
				{
					investmentService.deleteByInvestmentid(investmentid);
				return new ResponseEntity<>("deleted succesfully ",HttpStatus.OK);
				}
				else {
				return new ResponseEntity<>("Investment not found ",HttpStatus.NOT_FOUND);
				}
			}
			
			//for filtering by Company, Currency,State,Country
			@GetMapping("/Investmentfilter")
			public ResponseEntity<List<Investment>> findByCompanynameOrCurrencyOrStateOrCountry(@RequestParam(required=false) String company,@RequestParam(required=false) String currency,@RequestParam(required=false) String state, @RequestParam(required=false) String country) {
				return new ResponseEntity<List<Investment>>(investmentService.findByCompanyOrCurrencyOrStateOrCountry(company, currency,state,country), HttpStatus.OK);
			}
			
			@RequestMapping(value = "/updateInvestment",method=RequestMethod.PUT)
			public @ResponseBody ResponseEntity<?> updateInvestment(@RequestParam("investmentid") long investmentid,
					@RequestParam("purpose") String purpose,@RequestParam("amount") long amount,@RequestParam("payment_Method") long payment_Method,
					@RequestParam("currency") String currency,@RequestParam("") String company,@RequestParam("country") String country,
					@RequestParam("state") String state,@RequestParam("branch") String branch,@RequestParam("description") String description,
					Model model, HttpServletRequest request,final @RequestParam("invoice") MultipartFile invoicefile){
				
				try {
					String uploadDirectory=request.getServletContext().getRealPath(uploadFolder);
					log.info("uploadDirectory::"+uploadDirectory);
					String fileName=invoicefile.getOriginalFilename();
					String filepath=Paths.get(uploadDirectory, fileName).toString();
					log.info("Filename:"+invoicefile.getOriginalFilename());
					if(fileName==null || fileName.contains(".."))
					{
						model.addAttribute("invalid","Sorry! filename conatains invalid path"+fileName);
						return new ResponseEntity<>("Sorry! filename contains invalid path"+fileName,HttpStatus.BAD_REQUEST);
					}
					try {
						File dir = new File(uploadDirectory);
						if (!dir.exists()) {
							log.info("Folder Created");
							dir.mkdirs();
						}
						BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filepath)));
						stream.write(fileName.getBytes());
						stream.close();
					}
					catch (Exception e) {
						log.info("in catch");
						e.printStackTrace();
					}
					byte[] invoiceData = invoicefile.getBytes();
					Investment investment = new Investment();
					investment.setInvestmentid(investmentid);
					investment.setAmount(amount);
					investment.setBranch(branch);
					investment.setCompany(company);
					investment.setCountry(country);
					investment.setCurrency(currency);
					investment.setDescription(description);
					investment.setInvoice(invoiceData);
					investment.setPayment_Method(payment_Method);
					investment.setPurpose(purpose);
					investment.setState(state);
					
					investmentService.update(investmentid, invoiceData, purpose, amount, payment_Method,
							currency, company, country, state, branch, description);
					
					return new ResponseEntity<>("success",HttpStatus.OK);
					
				}
				catch (Exception e) {
					e.printStackTrace();
					log.info("Exception: " + e);
					return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
				}
			}
			
			@GetMapping("/sortingInvest")
			public ResponseEntity<Page<Investment>> getPageInverst(InvestmentPage investmentPage,
					InvestmentSearchCriteria investmentSearchCriteria){
			    return new ResponseEntity<>(investmentService.getEmployees(investmentPage, investmentSearchCriteria),
			            HttpStatus.OK);
			    
			}
			
}
