package com.spring.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.spring.example.Exception.BadRequestException;
import com.spring.example.Exception.FileStorageException;
import com.spring.example.model.Investment;
import com.spring.example.service.InvestmentFileService;
import com.spring.example.service.InvestmentService;

@RestController
public class InvestmentController {
	
	@Autowired
	private InvestmentService investmentService;
	
	@Autowired
	private InvestmentFileService investmentFileService;
	
	@PostMapping("/AddInvestement")
	public @ResponseBody ResponseEntity<?> createInvestment(@RequestBody Investment investment) {
		
		try {
				investmentService.save(investment);
			return new ResponseEntity<>("successfully created",HttpStatus.OK);
			
		}
		catch(BadRequestException e) {
			 return new ResponseEntity<>("you are trying to add null value",HttpStatus.BAD_REQUEST);
		}
		catch(DataIntegrityViolationException e) {
			//throw new DataIntegrityViolationException("employee already exists",e);
			return new ResponseEntity<>("employee already exists with this mail id ",HttpStatus.CONFLICT);
		}
	
	}
	
	@RequestMapping(value = "/listAllInv",method=RequestMethod.GET)
	public List<Investment> listAll()
	{
		if(investmentService.listAll()==null)
		{
			throw new NullPointerException("No Investment were found");
		}
		System.out.println("getting records");
		
		return investmentService.listAll();
	}
	
	@RequestMapping(value = "/deleteAllInv",method=RequestMethod.DELETE)
	public String deleteAll()
	{
		investmentService.delete();
		return "all records deleted successfully";
	}
	
	@RequestMapping(value = "/updateInvestment",method=RequestMethod.PUT)
	public @ResponseBody ResponseEntity<?> updateInvestment(@RequestBody Investment investment, @RequestParam long investmentid ) {
		investmentService.update(investment,investmentid);
		
		System.out.println(investment+""+investmentid);
			return new ResponseEntity<>("updated successfully",HttpStatus.OK);			
			
		}	
	
	//get single Investment details
		@RequestMapping(value = "/getInvestment",method=RequestMethod.GET)
		public Investment getInvestment(@RequestParam long investmentid) {
			System.out.println("getting record!!!!");
			return investmentService.findByInvestmentid(investmentid)
				.orElseThrow(()-> new UsernameNotFoundException("Investemnt Does not exist wit the id   "+investmentid));
		}
		

		//delete single Investment details
		@DeleteMapping("/deleteInvestement")
		public ResponseEntity<?> delete(@RequestParam long investmentid) {
			Optional<Investment> details=investmentService.findByInvestmentid(investmentid);
			if(details.isPresent())
			{
				investmentService.deleteByInvestmentid(investmentid);
			return new ResponseEntity<>("deleted succesfully ",HttpStatus.OK);
			}
			else {
			return new ResponseEntity<>("Investment not found ",HttpStatus.NOT_FOUND);
			}
		}
		
		//for filtering by Company, Currency,State,Country
		@GetMapping("/Investmentfilter")
		public ResponseEntity<List<Investment>> findByCompanynameOrCurrencyOrStateOrCountry(@RequestParam(required=false) String company,@RequestParam(required=false) String currency,@RequestParam(required=false) String state, @RequestParam(required=false) String country) {
			return new ResponseEntity<List<Investment>>(investmentService.findByCompanyOrCurrencyOrStateOrCountry(company, currency,state,country), HttpStatus.OK);
		}
		
		 @PostMapping("/uploadInvFile")
		  public ResponseEntity<FileStorageException> uploadFile(@RequestParam("invfile") MultipartFile invfile) {
		    String message = "";
		    try {
		    	
		    	investmentFileService.store(invfile);

		      message = "Uploaded the file successfully: " + invfile.getOriginalFilename();
		      return ResponseEntity.status(HttpStatus.OK).body(new FileStorageException(message));
		    }
		    catch (Exception e) {
		      message = "Could not upload the file: " + invfile.getOriginalFilename() + "!";
		      return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new FileStorageException(message));
		    }
		  }
		
}
