package com.spring.example.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.example.model.EducationalDetails;

@Repository
public interface EducationDetailsRepository extends JpaRepository<EducationalDetails, Integer> {

	void deleteByedid(long edid);

	Optional<EducationalDetails> findByedid(long edid);

	EducationalDetails findByEdid(int edid);

	Optional<EducationalDetails> findByempId(long empId);

	EducationalDetails findByEmpId(long empId);

}
