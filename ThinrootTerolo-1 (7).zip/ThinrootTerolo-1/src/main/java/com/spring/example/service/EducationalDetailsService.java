package com.spring.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.example.Exception.BadRequestException;
import com.spring.example.model.EducationalDetails;
import com.spring.example.repository.EducationDetailsRepository;
import com.spring.example.validation.EducationalDetailsValidation;

@Service
public class EducationalDetailsService {

	@Autowired
	private EducationDetailsRepository edudetailsRepository;
	
	@Autowired
	private EducationalDetailsValidation educationValidation;
	
	//save employee
			public void Save(EducationalDetails educationalDetails) {
				
				List<Error> errors =educationValidation.validateCreateEducationRequest(educationalDetails);
				
				if(errors.size() > 0) { 
					   throw new BadRequestException("you have missed the some values ",errors); 
				   }
				edudetailsRepository.save(educationalDetails);
			}
			
			 // get all
			public List<EducationalDetails> listAll()
			{
				return (List<EducationalDetails>) edudetailsRepository.findAll();
				
			}
			
			//delete by id
			public void deleteByempId(long edid) {
				edudetailsRepository.deleteByedid(edid);
			}
			
			//get A single employee details
			public Optional<EducationalDetails> findByEmpId(long empId) {
				
				return edudetailsRepository.findByempId(empId);
			}
			
			// update 
			
			public EducationalDetails update(EducationalDetails details,long empId)
			{
				
				EducationalDetails  edudetails2 =edudetailsRepository.findByEmpId(empId);
				
				edudetails2.setEmpId(empId);
				edudetails2.setCollege(details.getCollege());
				edudetails2.setQualification(details.getQualification());
				edudetails2.setStartYear(details.getStartYear());
				edudetails2.setEndYear(details.getEndYear());
				edudetails2.setSummary(details.getSummary());
				
				edudetails2.setScl(details.getScl());
				edudetails2.setGrade(details.getGrade());
				edudetails2.setSclstartYear(details.getSclstartYear());
				edudetails2.setSclendYear(details.getSclendYear());
				edudetails2.setSclsummary(details.getSclsummary());
			
				return edudetailsRepository.save(edudetails2);
			}
			
			//deleteAll
			public void delete()
			{
				edudetailsRepository.deleteAll();
			}

}
