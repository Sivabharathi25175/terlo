package com.spring.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.example.model.EmployeeDetails;

@Repository
public interface EmployeeDetailsModuleRepository extends JpaRepository<EmployeeDetails, Long>{

	

}
