package com.spring.example.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.example.model.Investment;

@Repository
public interface InvestmentRepository extends JpaRepository<Investment, Long> {

	void deleteByInvestmentid(long investmentid);

	Optional<Investment> findByInvestmentid(long investmentid);

	Investment findByinvestmentid(long investmentid);

	List<Investment> findByCompanyOrCurrencyOrStateOrCountry(String company, String currency, String state,
			String country);

}
