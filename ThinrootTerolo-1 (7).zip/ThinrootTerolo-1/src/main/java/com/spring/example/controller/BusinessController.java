package com.spring.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.spring.example.Exception.BadRequestException;
import com.spring.example.Exception.FileStorageException;
import com.spring.example.model.Business;
import com.spring.example.repository.BusinessRepository;
import com.spring.example.service.BusinessService;
import com.spring.example.service.FileUploadServices;

@RestController
public class BusinessController {
	
	@Autowired
	private BusinessService businessOpService;
	
	@Autowired
	private BusinessRepository businessRepository;
	
	@Autowired
	private FileUploadServices fileUploadServices;
	
	@Value("${file.upload-dir}")
	String FileUploadPath;
	
	@PostMapping("/AddDetails")
	public @ResponseBody ResponseEntity<?> createBusiness(@RequestBody Business business) {
		
		try {
			Optional<Business> details=businessRepository.findByBusinessid(business.getBusinessid());
			if(!details.isPresent())
			{
				businessOpService.save(business);
			return new ResponseEntity<>("successfully created",HttpStatus.OK);
			}
			else {
				return new ResponseEntity<>("employee already exists",HttpStatus.CONFLICT);
			}
		}
		catch(BadRequestException e) {
			 return new ResponseEntity<>("you are trying to add null value",HttpStatus.BAD_REQUEST);
		}
		catch(DataIntegrityViolationException e) {
			//throw new DataIntegrityViolationException("employee already exists",e);
			return new ResponseEntity<>("Business already exists with this mail id ",HttpStatus.CONFLICT);
		}
	
	}
	
	
	@RequestMapping(value = "/listAll",method=RequestMethod.GET)
	public List<Business> listAll()
	{
		if(businessOpService.listAll()==null)
		{
			throw new NullPointerException("No Business were found");
		}
		System.out.println("getting records");
		
		return businessOpService.listAll();
	}
	
	@RequestMapping(value = "/deleteAll",method=RequestMethod.DELETE)
	public String deleteAll()
	{
		businessOpService.delete();
		return "all records deleted successfully";
	}
	
	@RequestMapping(value = "/update",method=RequestMethod.PUT)
	public @ResponseBody ResponseEntity<?> updatebusiness(@RequestBody Business business, @RequestParam long businessid ) {
		businessOpService.update(business,businessid);
		
		System.out.println(business+""+businessid);
			return new ResponseEntity<>("updated successfully",HttpStatus.OK);			
			
		}	
	
	//get single Business details
		@RequestMapping(value = "/getBusiness",method=RequestMethod.GET)
		public Business getBusiness(@RequestParam long businessid) {
			System.out.println("getting record!!!!");
			return businessOpService.findByBusinessid(businessid)
				.orElseThrow(()-> new UsernameNotFoundException("business Does not exist wit the id   "+businessid));
		}
		

		//delete single Business details
		@DeleteMapping("/deletebusiness")
		public ResponseEntity<?> delete(@RequestParam long businessid) {
			Optional<Business> details=businessOpService.findByBusinessid(businessid);
			if(details.isPresent())
			{
				businessOpService.deleteByBusinessid(businessid);
			return new ResponseEntity<>("deleted succesfully ",HttpStatus.OK);
			}
			else {
			return new ResponseEntity<>("employee not found ",HttpStatus.NOT_FOUND);
			}
		}
		
		//for filtering by email,mobile number,name,name
		@GetMapping("/filters")
		public ResponseEntity<List<Business>> getByCompanynameOrCategoryOrTypeOrStateOrCountry(@RequestParam(required=false) String companyname,@RequestParam(required=false) String category,@RequestParam(required=false) String type,@RequestParam(required=false) String state, @RequestParam(required=false) String country) {
			return new ResponseEntity<List<Business>>(businessOpService.findByCompanynameOrCategoryOrTypeOrStateOrCountry(companyname,category,
					 type, state, country), HttpStatus.OK);
		}
		
		@PostMapping("/uploadFile")
		  public ResponseEntity<FileStorageException> uploadFile(@RequestParam("file") MultipartFile file) {
		    String message = "";
		    try {
		    	fileUploadServices.store(file);

		      message = "Uploaded the file successfully: " + file.getOriginalFilename();
		      return ResponseEntity.status(HttpStatus.OK).body(new FileStorageException(message));
		    }
		    catch (Exception e) {
		      message = "Could not upload the file: " + file.getOriginalFilename() + "!";
		      return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new FileStorageException(message));
		    }
		  }
		
		  @PostMapping("/uploadFileImage")
		  public ResponseEntity<FileStorageException> uploadImage(@RequestParam("image") MultipartFile image) {
		    String message = "";
		    try {
		    	fileUploadServices.storeImage(image);

		      message = "Uploaded the file successfully: " + image.getOriginalFilename();
		      return ResponseEntity.status(HttpStatus.OK).body(new FileStorageException(message));
		    }
		    catch (Exception e) {
		      message = "Could not upload the file: " + image.getOriginalFilename() + "!";
		      return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new FileStorageException(message));
		    }
		  }
}
