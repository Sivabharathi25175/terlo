package com.spring.example.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Experience {

	@Id
	private int ExpId;
	private String Designation;
	private long empId;
	
	public Experience() {
		super();
		
	}

	public Experience(int expId, String designation, long empId) {
		super();
		ExpId = expId;
		Designation = designation;
		this.empId = empId;
	}

	public int getExpId() {
		return ExpId;
	}

	public void setExpId(int expId) {
		ExpId = expId;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public long getEmpId() {
		return empId;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}
	
	
}
