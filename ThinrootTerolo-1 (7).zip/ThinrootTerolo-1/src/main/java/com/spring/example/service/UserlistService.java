package com.spring.example.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.spring.example.model.DAOUser;
import com.spring.example.repository.UserRepository;

@Service
public class UserlistService {

	@Autowired
	private UserRepository UserRepo;
	
	@Autowired
	private PasswordEncoder bcryptEncoder;
	
	public DAOUser getUser(String username)
	{
		return UserRepo.findByUsername(username);
		
	}
	
	public DAOUser update( DAOUser user,String username) {
		
		DAOUser newUser = UserRepo.findByUsername(username);
		return UserRepo.save(newUser);
	}
	
	public String deleteByuser(String username) {

		UserRepo.deleteByUsername(username);
		return "deleted "+username;
	}
	
	// find by email
	public Optional<DAOUser> findUserByEmail(String email)
	{
		
		return UserRepo.findByEmail(email);
	}
	
	//find by reset token
	public Optional<DAOUser> findUserByResetToken(String resetToken)
	{
		return UserRepo.findByResetToken(resetToken);
		
	}
	
	public void saveUser(DAOUser user)
	{
		UserRepo.save(user);
	}

}
