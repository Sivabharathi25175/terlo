package com.spring.example.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Company {

	@Id
	private int compId;
	private String Company;
	private long empId;
	
	public Company() {
		super();
	}

	public Company(int compId, String company, long empId) {
		super();
		this.compId = compId;
		Company = company;
		this.empId = empId;
	}

	public int getCompId() {
		return compId;
	}

	public void setCompId(int compId) {
		this.compId = compId;
	}

	public String getCompany() {
		return Company;
	}

	public void setCompany(String company) {
		Company = company;
	}

	public long getEmpId() {
		return empId;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}
	
}
