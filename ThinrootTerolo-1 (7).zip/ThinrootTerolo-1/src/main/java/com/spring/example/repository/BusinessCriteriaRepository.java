package com.spring.example.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.domain.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.spring.example.model.Business;
import com.spring.example.model.BusinessPage;
import com.spring.example.model.BusinessSearchCriteria;

@Repository
public class BusinessCriteriaRepository {

	private final EntityManager entityManager;
    private final CriteriaBuilder criteriaBuilder;
    
    public BusinessCriteriaRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
        this.criteriaBuilder = entityManager.getCriteriaBuilder();
    }

	public Page<Business> findAllWithFilters(BusinessPage businessPage, BusinessSearchCriteria businessSearchCriteria) {
		CriteriaQuery<Business> criteriaQuery = criteriaBuilder.createQuery(Business.class);
        Root<Business> BusinessRoot = criteriaQuery.from(Business.class);
        Predicate predicate = getPredicate(businessSearchCriteria, BusinessRoot);
        criteriaQuery.where(predicate);
        setOrder(businessPage, criteriaQuery, BusinessRoot);

        TypedQuery<Business> typedQuery = entityManager.createQuery(criteriaQuery);
        typedQuery.setFirstResult(businessPage.getPageNumber() * businessPage.getPageSize());
        typedQuery.setMaxResults(businessPage.getPageSize());

        Pageable pageable = getPageable(businessPage);

        long employeesCount = getBusinessCount(predicate);

        return new PageImpl<>(typedQuery.getResultList(), pageable, employeesCount);
	}

	private Predicate getPredicate(BusinessSearchCriteria businessSearchCriteria, Root<Business> businessRoot) {
		 List<Predicate> predicates = new ArrayList<>();
		  if(Objects.nonNull(businessSearchCriteria.getCompanyname())){
	            predicates.add(
	                    criteriaBuilder.like(businessRoot.get("companyname"),
	                            "%" + businessSearchCriteria.getCompanyname() + "%")
	            );
	        }
		  if(Objects.nonNull(businessSearchCriteria.getCategory())){
	            predicates.add(
	                    criteriaBuilder.like(businessRoot.get("category"),
	                            "%" + businessSearchCriteria.getCategory() + "%")
	            );
	        }
		  if(Objects.nonNull(businessSearchCriteria.getType())){
	            predicates.add(
	                    criteriaBuilder.like(businessRoot.get("type"),
	                            "%" + businessSearchCriteria.getType() + "%")
	            );
	        }
		  if(Objects.nonNull(businessSearchCriteria.getState())){
	            predicates.add(
	                    criteriaBuilder.like(businessRoot.get("country"),
	                            "%" + businessSearchCriteria.getState() + "%")
	            );
	        }
		  if(Objects.nonNull(businessSearchCriteria.getCountry())){
	            predicates.add(
	                    criteriaBuilder.like(businessRoot.get("state"),
	                            "%" + businessSearchCriteria.getCountry() + "%")
	            );
	        }
		  return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
	}
	
	private long getBusinessCount(Predicate predicate) {
	    CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        Root<Business> countRoot = countQuery.from(Business.class);
        countQuery.select(criteriaBuilder.count(countRoot)).where(predicate);
        return entityManager.createQuery(countQuery).getSingleResult();
	}

	private Pageable getPageable(BusinessPage businessPage) {
		 Sort sort = Sort.by(businessPage.getSortDirection(), businessPage.getSortBy());
	        return PageRequest.of(businessPage.getPageNumber(),businessPage.getPageSize(), sort);
	}

	private void setOrder(BusinessPage businessPage, CriteriaQuery<Business> criteriaQuery,
			Root<Business> businessRoot) {
		if(businessPage.getSortDirection().equals(Sort.Direction.ASC)){
            criteriaQuery.orderBy(criteriaBuilder.asc(businessRoot.get(businessPage.getSortBy())));
        } else {
            criteriaQuery.orderBy(criteriaBuilder.desc(businessRoot.get(businessPage.getSortBy())));
        }
		
	}
    
}
