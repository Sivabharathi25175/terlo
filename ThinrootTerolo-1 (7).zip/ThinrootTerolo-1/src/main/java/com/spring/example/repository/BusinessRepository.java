package com.spring.example.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.example.model.Business;


@Repository
public interface BusinessRepository extends JpaRepository<Business, Long>{
	
	public Business findBybusinessid(long businessid);

	public void deleteByBusinessid(long businessid);

	public Optional<Business> findByBusinessid(long businessid);

	public List<Business> findByCompanynameOrCategoryOrTypeOrStateOrCountry(String companyname, String category,
			String type, String state, String country);

	
		
}
