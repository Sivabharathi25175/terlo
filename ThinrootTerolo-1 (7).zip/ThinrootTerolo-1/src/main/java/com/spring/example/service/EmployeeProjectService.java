package com.spring.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.example.Exception.BadRequestException;
import com.spring.example.model.EmployeeProject;
import com.spring.example.repository.EmployeeProjectRepository;
import com.spring.example.validation.EmployeeProjectValidation;

@Service
public class EmployeeProjectService {

	@Autowired
	private EmployeeProjectRepository employeeProjectRepository;
	
	@Autowired
	private EmployeeProjectValidation validation;
	
	//save employee
			public void Save(EmployeeProject project) {
				
				List<Error> errors =validation.validateCreateProjectRequest(project);
				
				if(errors.size() > 0) { 
					   throw new BadRequestException("you have missed the some values ",errors); 
				   }
				employeeProjectRepository.save(project);
			}
			
			 // get all
			public List<EmployeeProject> listAll()
			{
				return (List<EmployeeProject>) employeeProjectRepository.findAll();
				
			}
			
			//delete by id
			public void deleteByprojectid(long empId) {
				employeeProjectRepository.deleteByprojectid(empId);
			}
			
			//get a single employee details
			public Optional<EmployeeProject> findByprojectid(long empId) {
				
				return employeeProjectRepository.findByprojectid(empId);
			}
			
			// update 
			
			public EmployeeProject update(EmployeeProject project,long empId)
			{
				
				EmployeeProject  project2 =employeeProjectRepository.findByEmpId(empId);
				project2.setEmpId(empId);
				project2.setDesignation(project.getDesignation());
				project2.setEndDateYear(project.getEndDateYear());
				project2.setCompanyName(project.getCompanyName());
				project2.setStartDateYear(project.getStartDateYear());
				project2.setSummary(project.getSummary());
				project2.setProject(project.getProject());
				return employeeProjectRepository.save(project2);
			}
			
			//deleteAll
			public void delete()
			{
				employeeProjectRepository.deleteAll();
			}
			
			
}
