package com.spring.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.example.model.FileUpload;
import com.spring.example.model.InvestmentFile;

@Repository
public interface InvestmentFileRepository extends JpaRepository<InvestmentFile, String>{

	FileUpload save(FileUpload fileDB);


}
