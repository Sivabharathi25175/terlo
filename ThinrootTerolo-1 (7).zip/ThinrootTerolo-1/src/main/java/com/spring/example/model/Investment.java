package com.spring.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity
public class Investment {

	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private long investmentid;
	@Column(length = 1000)
	private byte[] invoice;
	private String purpose;
	private long amount;
	private long payment_Method;
	private String currency;
	private String company;
	private String country;
	private String state;
	private String branch;
	private String description;
	
	public Investment() {
		super();
	}

	public Investment(long investmentid, byte[] invoice, String purpose, long amount, long payment_Method,
			String currency, String company, String country, String state, String branch, String description) {
		super();
		this.investmentid = investmentid;
		this.invoice = invoice;
		this.purpose = purpose;
		this.amount = amount;
		this.payment_Method = payment_Method;
		this.currency = currency;
		this.company = company;
		this.country = country;
		this.state = state;
		this.branch = branch;
		this.description = description;
	}

	public long getInvestmentid() {
		return investmentid;
	}

	public void setInvestmentid(long investmentid) {
		this.investmentid = investmentid;
	}

	public byte[] getInvoice() {
		return invoice;
	}

	public void setInvoice(byte[] invoice) {
		this.invoice = invoice;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public long getPayment_Method() {
		return payment_Method;
	}

	public void setPayment_Method(long payment_Method) {
		this.payment_Method = payment_Method;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
