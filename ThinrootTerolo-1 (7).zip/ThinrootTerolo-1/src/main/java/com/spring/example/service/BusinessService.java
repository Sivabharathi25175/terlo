package com.spring.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.example.Exception.BadRequestException;
import com.spring.example.model.Business;
import com.spring.example.model.BusinessPage;
import com.spring.example.model.BusinessSearchCriteria;
import com.spring.example.model.Shareholders;
import com.spring.example.repository.BusinessCriteriaRepository;
import com.spring.example.repository.BusinessRepository;
import com.spring.example.validation.BusinessValidation;

@Service
@Transactional
public class BusinessService {

	@Autowired
	private BusinessRepository businessRepository;
	
	@Autowired
	private BusinessValidation businessValidation;
	
	@Autowired
	private BusinessCriteriaRepository businessCriteriaRepository;
	
	//create
	public void Save(Business businessOp) {
	
		List<Error> errors =businessValidation.validateCreateBusinessRequest(businessOp);
		 
		//if not success
		  if(errors.size() > 0) { 
			   throw new BadRequestException("you have missed the some values ",errors); 
		   }
		   
		businessRepository.save(businessOp);
	}
	
	// get all
		public List<Business> listAll()
		{
			return (List<Business>) businessRepository.findAll();
			
		}
		
		//delete by id
		public void deleteByBusinessid(long businessid) {
			businessRepository.deleteByBusinessid(businessid);
		}
		
		//getA single employee details
		public Optional<Business> findByBusinessid(long businessid) {
			
			return businessRepository.findByBusinessid(businessid);
		}
		
		// update 
		
		public Business update(long businessid, byte[] photo, String companyname, String gstno, String category, String type,
				int paidupcapital, int authorisedcapital, String ceo, int employee, byte[] file, List<Shareholders> shareholder,
				String address1, String address2, String compname, String country, String state)
		{
			
			Business bsop  =businessRepository.findById(businessid).get();
			
			bsop.setBusinessid(businessid);
			bsop.setAddress1(address1);
			bsop.setAddress2(address2);
			bsop.setAuthorisedcapital(authorisedcapital);
			bsop.setCategory(category);
			bsop.setCeo(ceo);
			bsop.setCompanyname(companyname);
			bsop.setCompname(compname);
			bsop.setCountry(country);
			bsop.setEmployee(employee);
			bsop.setFile(file);
			bsop.setGstno(gstno);
			bsop.setPaidupcapital(paidupcapital);
			bsop.setPhoto(photo);
			bsop.setShareholder(shareholder);
			bsop.setState(state);
			bsop.setType(type);
			return businessRepository.save(bsop);
		}
		
		//deleteAll
		public void delete()
		{
			businessRepository.deleteAll();
		}
		
		// search
		public List<Business> findByCompanynameOrCategoryOrTypeOrStateOrCountry(String companyname, String category,
				String type,String state,String country) {
			return businessRepository.findByCompanynameOrCategoryOrTypeOrStateOrCountry(companyname, category,type,state,country);
		}
		
		public Page<Business> getBusiness(BusinessPage businessPage,
				BusinessSearchCriteria businessSearchCriteria){
			return businessCriteriaRepository.findAllWithFilters(businessPage, businessSearchCriteria);
}
}
