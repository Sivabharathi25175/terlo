package com.spring.example.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.spring.example.model.InvestmentFile;
import com.spring.example.repository.InvestmentFileRepository;

@Service
public class InvestmentFileService {

		@Autowired
		private InvestmentFileRepository investmentFileRepository;
		
		public InvestmentFile store(MultipartFile file) throws IOException {
		    String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		    InvestmentFile FileDB = new InvestmentFile(fileName, file.getContentType(), file.getBytes());

		    return investmentFileRepository.save(FileDB);
		  }
}
