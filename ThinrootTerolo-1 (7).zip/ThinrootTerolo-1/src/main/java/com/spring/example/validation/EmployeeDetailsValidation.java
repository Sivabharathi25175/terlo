package com.spring.example.validation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.spring.example.model.EmployeeDetails;

@Component
public class EmployeeDetailsValidation {

	public List<Error> validateCreateEmployeeRequest(EmployeeDetails details) {
	
		List<Error> errors = new ArrayList<>();
		
		 if(details.getFirstName()==null) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		 if(details.getLastName()==null) {
        	 Error error = new Error("LastName is null");
             errors.add(error);
        }
		 if(details.getAbilities()==null) {
        	 Error error = new Error("Abilities is null");
             errors.add(error);
        }
		 if(details.getBlood_Group()==null) {
        	 Error error = new Error("Blood_Group is null");
             errors.add(error);
        }
		 if(details.getCompany()==null) {
        	 Error error = new Error("Company is null");
             errors.add(error);
        }
		 if(details.getDate_of_Birth()==null) {
        	 Error error = new Error("Date_of_Birth is null");
             errors.add(error);
        }
		 if(details.getDesignation()==null) {
        	 Error error = new Error("Designation name is null");
             errors.add(error);
        }
		 if(details.getExperince()==null) {
       	 Error error = new Error("Experince is null");
         errors.add(error);
        }
        if(details.getGender()==null) {
       	 Error error = new Error("Gender is null");
            errors.add(error);
       }
        if(details.getInfo()==null) {
          	 Error error = new Error("FirstName name is null");
               errors.add(error);
          }
        if(details.getLanguage()==null) {
          	 Error error = new Error("Language is null");
               errors.add(error);
          }
        if(details.getMailId()==null) {
          	 Error error = new Error("MailId is null");
               errors.add(error);
          }
        if(details.getMobileNumber()==null) {
          	 Error error = new Error("MobileNumber is null");
               errors.add(error);
          }
        if(details.getRole()==null) {
         	 Error error = new Error("Role is null");
              errors.add(error);
         }
        if(details.getSkill()==null) {
         	 Error error = new Error("Skill is null");
              errors.add(error);
         }
        if(details.getTools()==null) {
        	 Error error = new Error("Tools is null");
             errors.add(error);
        }
        if(details.getSkypeId()==null) {
        	 Error error = new Error("Skype name is null");
             errors.add(error);
        }
		return errors;
	}
}
