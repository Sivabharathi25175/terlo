package com.spring.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.spring.example.model.EmployeeDetails;
import com.spring.example.model.EmployeePage;
import com.spring.example.model.EmployeeSearchCriteria;
import com.spring.example.repository.EmployeeCriteriaRepository;
import com.spring.example.repository.EmployeeDetailsModuleRepository;

@Service
public class EmployeeDetailsModuleService {

	
	@Autowired
	private EmployeeDetailsModuleRepository detailsRepository;
	
	@Autowired
	private EmployeeCriteriaRepository employeeCriteriaRepository;
	
	
	//save employee
		public void Save(EmployeeDetails employeeDetails) {
			
			detailsRepository.save(employeeDetails);
		}
		
		 // get all
		public List<EmployeeDetails> listAll()
		{
			return (List<EmployeeDetails>) detailsRepository.findAll();
			
		}
		
		//delete by id
		public void deleteByempId(long empId) {
			detailsRepository.deleteById(empId);
		}
		
		//getA single employee details
		public Optional<EmployeeDetails> findByEmpId(long empId) {
			
			return detailsRepository.findById(empId);
		}
		
		//deleteAll
		public void delete()
		{
			detailsRepository.deleteAll();
		}
		
		public EmployeeDetails update(long empId, String firstName, String lastName, String experince, String info,
				String mobileNumber, String mailId, String skypeId, byte[] photo, String date_of_Birth, String blood_Group,
				String gender, String language, String designation, String company, String tools, String skill, String role,
				String abilities)
		{
			
			EmployeeDetails  details2 =detailsRepository.findById(empId).get();
			
			details2.setEmpId(empId);
			details2.setAbilities(abilities);
			details2.setBlood_Group(blood_Group);
			details2.setCompany(company);
			details2.setDate_of_Birth(date_of_Birth);
			details2.setExperince(experince);
			details2.setFirstName(firstName);
			details2.setGender(gender);
			details2.setInfo(info);
			details2.setLanguage(language);
			details2.setLastName(lastName);
			details2.setLastName(lastName);
			details2.setMailId(mailId);
			details2.setMobileNumber(mobileNumber);
			details2.setPhoto(photo);
			details2.setRole(role);
			details2.setSkill(skill);
			details2.setSkypeId(skypeId);
			details2.setTools(tools);
			
			return detailsRepository.save(details2);
		}
		
		 public Page<EmployeeDetails> getEmployees(EmployeePage employeePage,
                 EmployeeSearchCriteria employeeSearchCriteria){
			 return employeeCriteriaRepository.findAllWithFilters(employeePage, employeeSearchCriteria);
}
}
