package com.spring.example.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.spring.example.model.FileUpload;
import com.spring.example.model.Image;
import com.spring.example.repository.FileRepository;
import com.spring.example.repository.ImageRepository;

@Service
public class FileUploadServices {

	@Autowired
	private FileRepository fileRepository;
	
	@Autowired
	private ImageRepository imageRepository;
	
	public FileUpload store(MultipartFile file) throws IOException {
	    String fileName = StringUtils.cleanPath(file.getOriginalFilename());
	    FileUpload FileDB = new FileUpload(fileName, file.getContentType(), file.getBytes());

	    return fileRepository.save(FileDB);
	  }
	
	public Image storeImage(MultipartFile image) throws IOException {
	    String fileName = StringUtils.cleanPath(image.getOriginalFilename());
	    Image attachment = new Image(fileName,image.getContentType(), image.getBytes());
        return imageRepository.save(attachment);
	  }
	
}
