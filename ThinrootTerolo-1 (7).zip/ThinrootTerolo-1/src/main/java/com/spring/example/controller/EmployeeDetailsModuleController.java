package com.spring.example.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.spring.example.model.EmployeeDetails;
import com.spring.example.model.EmployeePage;
import com.spring.example.model.EmployeeSearchCriteria;
import com.spring.example.service.EmployeeDetailsModuleService;

@RestController
public class EmployeeDetailsModuleController {

	@Autowired
	private EmployeeDetailsModuleService employeeDetailsService;
	
	@Value("${upoadDir}")
	private String uploadFolder;
	
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@PostMapping("/AddEmp")
	public @ResponseBody ResponseEntity<?> createBusiness(@RequestParam("empId") long empId,@RequestParam("firstName") String firstName,
		   @RequestParam("lastName") String lastName,@RequestParam("experince") String experince,@RequestParam("info") String info,
		   @RequestParam("mobileNumber") String mobileNumber,@RequestParam("mailId") String mailId,@RequestParam("skypeId") String skypeId,
		   @RequestParam("date_of_Birth") String date_of_Birth,@RequestParam("blood_Group") String blood_Group,@RequestParam("gender") String gender,
		   @RequestParam("language") String language,@RequestParam("designation") String designation,@RequestParam("company") String company,
		   @RequestParam("tools") String tools,@RequestParam("skill") String skill,@RequestParam("role") String role,
		   @RequestParam("abilities")String abilities,Model model,HttpServletRequest request,final @RequestParam("photo") MultipartFile imagefile) {
		
		try {
			String uploadDirectory=request.getServletContext().getRealPath(uploadFolder);
			log.info("uploadDirectory::"+uploadDirectory);
			String fileName=imagefile.getOriginalFilename();
			String filepath=Paths.get(uploadDirectory, fileName).toString();
			log.info("Filename:"+imagefile.getOriginalFilename());
			if(fileName==null || fileName.contains(".."))
			{
				model.addAttribute("invalid","Sorry! filename conatains invalid path"+fileName);
				return new ResponseEntity<>("Sorry! filename contains invalid path"+fileName,HttpStatus.BAD_REQUEST);
			}
			try {
				File dir = new File(uploadDirectory);
				if (!dir.exists()) {
					log.info("Folder Created");
					dir.mkdirs();
				}
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filepath)));
				stream.write(fileName.getBytes());
				stream.close();
			}
			catch (Exception e) {
				log.info("in catch");
				e.printStackTrace();
			}
			byte[] imageData = imagefile.getBytes();
			
			EmployeeDetails employeeDetails = new EmployeeDetails();
			employeeDetails.setAbilities(abilities);
			employeeDetails.setBlood_Group(blood_Group);
			employeeDetails.setCompany(company);
			employeeDetails.setDate_of_Birth(date_of_Birth);
			employeeDetails.setEmpId(empId);
			employeeDetails.setExperince(experince);
			employeeDetails.setFirstName(firstName);
			employeeDetails.setGender(gender);
			employeeDetails.setInfo(info);
			employeeDetails.setLanguage(language);
			employeeDetails.setLastName(lastName);
			employeeDetails.setLastName(lastName);
			employeeDetails.setMailId(mailId);
			employeeDetails.setMobileNumber(mobileNumber);
			employeeDetails.setPhoto(imageData);
			employeeDetails.setRole(role);
			employeeDetails.setSkill(skill);
			employeeDetails.setSkypeId(skypeId);
			employeeDetails.setTools(tools);
			employeeDetails.setDesignation(designation);
			
			employeeDetailsService.Save(employeeDetails);
			
			return new ResponseEntity<>("success",HttpStatus.OK);
			
		}
			catch (Exception e) {
				e.printStackTrace();
				log.info("Exception: " + e);
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
	}
	
	@RequestMapping(value = "/listEmpAll",method=RequestMethod.GET)
	public List<EmployeeDetails> listAll()
	{
		if(employeeDetailsService.listAll()==null)
		{
			throw new NullPointerException("No Employee Details were found");
		}
		System.out.println("getting records");
		
		return employeeDetailsService.listAll();
	}
	
	@RequestMapping(value = "/deleteEmpAll",method=RequestMethod.DELETE)
	public String deleteAll()
	{
		employeeDetailsService.delete();
		return "all records deleted successfully";
	}
	
	//get single  details
	@RequestMapping(value = "/getEmp",method=RequestMethod.GET)
	public EmployeeDetails getByEmpId(@RequestParam long empId) {
		System.out.println("getting record!!!!");
		return employeeDetailsService.findByEmpId(empId)
			.orElseThrow(()-> new UsernameNotFoundException("Emp Does not exist wit the id   "+empId));
	}
	
	

	//delete single  details
	@DeleteMapping("/deleteEmp")
	public ResponseEntity<?> delete(@RequestParam long empId) {
		Optional<EmployeeDetails> details=employeeDetailsService.findByEmpId(empId);
		if(details.isPresent())
		{
			employeeDetailsService.deleteByempId(empId);
		return new ResponseEntity<>("deleted succesfully ",HttpStatus.OK);
		}
		else {
		return new ResponseEntity<>("employee not found ",HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value = "/updateEmp",method=RequestMethod.PUT)
	public @ResponseBody ResponseEntity<?> updatebusiness(@RequestParam("empId") long empId,@RequestParam("firstName") String firstName,
			   @RequestParam("lastName") String lastName,@RequestParam("experince") String experince,@RequestParam("info") String info,
			   @RequestParam("mobileNumber") String mobileNumber,@RequestParam("mailId") String mailId,@RequestParam("skypeId") String skypeId,
			   @RequestParam("date_of_Birth") String date_of_Birth,@RequestParam("blood_Group") String blood_Group,@RequestParam("gender") String gender,
			   @RequestParam("language") String language,@RequestParam("designation") String designation,@RequestParam("company") String company,
			   @RequestParam("tools") String tools,@RequestParam("skill") String skill,@RequestParam("role") String role,
			   @RequestParam("abilities")String abilities,Model model,HttpServletRequest request,final @RequestParam("photo") MultipartFile imagefile ) {
		try {
			String uploadDirectory=request.getServletContext().getRealPath(uploadFolder);
			log.info("uploadDirectory::"+uploadDirectory);
			String fileName=imagefile.getOriginalFilename();
			String filepath=Paths.get(uploadDirectory, fileName).toString();
			log.info("Filename:"+imagefile.getOriginalFilename());
			if(fileName==null || fileName.contains(".."))
			{
				model.addAttribute("invalid","Sorry! filename conatains invalid path"+fileName);
				return new ResponseEntity<>("Sorry! filename contains invalid path"+fileName,HttpStatus.BAD_REQUEST);
			}
			try {
				File dir = new File(uploadDirectory);
				if (!dir.exists()) {
					log.info("Folder Created");
					dir.mkdirs();
				}
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filepath)));
				stream.write(fileName.getBytes());
				stream.close();
			}
			catch (Exception e) {
				log.info("in catch");
				e.printStackTrace();
			}
			byte[] imageData = imagefile.getBytes();
			
			EmployeeDetails employeeDetails = new EmployeeDetails();
			employeeDetails.setAbilities(abilities);
			employeeDetails.setBlood_Group(blood_Group);
			employeeDetails.setCompany(company);
			employeeDetails.setDate_of_Birth(date_of_Birth);
			employeeDetails.setEmpId(empId);
			employeeDetails.setExperince(experince);
			employeeDetails.setFirstName(firstName);
			employeeDetails.setGender(gender);
			employeeDetails.setInfo(info);
			employeeDetails.setLanguage(language);
			employeeDetails.setLastName(lastName);
			employeeDetails.setLastName(lastName);
			employeeDetails.setMailId(mailId);
			employeeDetails.setMobileNumber(mobileNumber);
			employeeDetails.setPhoto(imageData);
			employeeDetails.setRole(role);
			employeeDetails.setSkill(skill);
			employeeDetails.setSkypeId(skypeId);
			employeeDetails.setTools(tools);
			
			employeeDetailsService.update(empId, firstName, lastName, experince, info, mobileNumber, mailId, skypeId, imageData,
					date_of_Birth, blood_Group, gender, language, designation, company, tools, skill, role, abilities);
			
			return new ResponseEntity<>("success",HttpStatus.OK);
			
		}
			catch (Exception e) {
				e.printStackTrace();
				log.info("Exception: " + e);
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		}
	
	@RequestMapping(value = "/sortingemployee",method=RequestMethod.GET)
	public ResponseEntity<Page<EmployeeDetails>> getEmployees(EmployeePage employeePage,
	                                                   EmployeeSearchCriteria employeeSearchCriteria){
	    return new ResponseEntity<>(employeeDetailsService.getEmployees(employeePage, employeeSearchCriteria),
	            HttpStatus.OK);
	    
	}
}
