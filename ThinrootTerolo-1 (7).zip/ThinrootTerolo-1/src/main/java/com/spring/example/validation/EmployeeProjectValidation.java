package com.spring.example.validation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.spring.example.model.EmployeeProject;

@Component
public class EmployeeProjectValidation {

	public List<Error> validateCreateProjectRequest(EmployeeProject employeeProject) {
		
		List<Error> errors = new ArrayList<>();
		
		 if(employeeProject.getDesignation()==null) {
       	 Error error = new Error("Designation is null");
            errors.add(error);
       }
		 if(employeeProject.getCompanyName()==null) {
	       	 Error error = new Error("Company Name is null");
	            errors.add(error);
	       }
		 if(employeeProject.getSummary()==null) {
	       	 Error error = new Error("Summary is null");
	            errors.add(error);
	       }
		 if(employeeProject.getStartDateYear()==0) {
	       	 Error error = new Error("From is null");
	            errors.add(error);
	       }
		 if(employeeProject.getEndDateYear()==0) {
	       	 Error error = new Error("To is null");
	            errors.add(error);
	       }
		 if(employeeProject.getProject()==null) {
	       	 Error error = new Error("Project is null");
	            errors.add(error);
	       }
		return errors;
	}
}
