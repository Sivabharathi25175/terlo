package com.spring.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.example.Exception.BadRequestException;
import com.spring.example.model.EmployeeProject;
import com.spring.example.service.EmployeeProjectService;

@RestController
public class EmployeeProjectController {
	
	@Autowired
	private EmployeeProjectService projectService;
	
	@PostMapping("/Addpro")
	public @ResponseBody ResponseEntity<?> createProject(@RequestBody EmployeeProject employeeProject ) {
		
		try {
			
			projectService.Save(employeeProject);
			return new ResponseEntity<>("successfully created",HttpStatus.OK);
			
		}
		catch(BadRequestException e) {
			 return new ResponseEntity<>("you are trying to add null value",HttpStatus.BAD_REQUEST);
		}
	
	}
	
	@PostMapping("/Addproject")
	public @ResponseBody ResponseEntity<?>createProject(@RequestParam("empId") long empId,@RequestParam("designation") String designation,
		   @RequestParam("companyName") String companyName,@RequestParam("startDateYear") int startDateYear,@RequestParam("endDateYear") int endDateYear,
		   @RequestParam("summary") String summary,@RequestParam("project") String project){
		

		EmployeeProject employeeProject2 = new EmployeeProject();
		employeeProject2.setCompanyName(companyName);
		employeeProject2.setDesignation(designation);
		employeeProject2.setEmpId(empId);
		employeeProject2.setEndDateYear(endDateYear);
		employeeProject2.setProject(project);
		employeeProject2.setStartDateYear(startDateYear);
		employeeProject2.setSummary(summary);
		
		projectService.Save(employeeProject2);
		return new ResponseEntity<>("success",HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/listProAll",method=RequestMethod.GET)
	public List<EmployeeProject> listAll()
	{
		if(projectService.listAll()==null)
		{
			throw new NullPointerException("No Emp Project were found");
		}
		System.out.println("getting records");
		
		return projectService.listAll();
	}
	
	@RequestMapping(value = "/deleteProAll",method=RequestMethod.DELETE)
	public String deleteAll()
	{
		projectService.delete();
		return "all records deleted successfully";
	}
	
	@RequestMapping(value = "/updatePro",method=RequestMethod.PUT)
	public @ResponseBody ResponseEntity<?> updateProject(@RequestBody EmployeeProject details, @RequestParam int projectid ) {
		projectService.update(details,projectid);
		
		System.out.println(details+""+projectid);
			return new ResponseEntity<>("updated successfully",HttpStatus.OK);			
			
		}	
	
	//get single  details
		@RequestMapping(value = "/getpro",method=RequestMethod.GET)
		public EmployeeProject getByProjectId(@RequestParam int projectid) {
			System.out.println("getting record!!!!");
			return projectService.findByprojectid(projectid)
				.orElseThrow(()-> new UsernameNotFoundException("business Does not exist wit the id   "+projectid));
		}
		
		

		//delete single  details
		@DeleteMapping("/deleteproject")
		public ResponseEntity<?> delete(@RequestParam int projectid) {
			Optional<EmployeeProject> details=projectService.findByprojectid(projectid);
			if(details.isPresent())
			{
				projectService.deleteByprojectid(projectid);
			return new ResponseEntity<>("deleted succesfully ",HttpStatus.OK);
			}
			else {
			return new ResponseEntity<>("Project not found ",HttpStatus.NOT_FOUND);
			}
		}

}
