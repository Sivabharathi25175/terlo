package com.spring.example.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Table
@Entity
public class EmployeeProject {

	@Id
	@Column(name="project_id",nullable=false)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int projectid;
	
	@Column(name="emp_id")
	private long empId;
	
	private String Designation;
	private String companyName;
	private int startDateYear;
	private int endDateYear;
	private String summary;
	private String project;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(foreignKey = @javax.persistence.ForeignKey(name = "fk_emp_id"), name="emp_id", referencedColumnName = "emp_id", columnDefinition = "long",insertable=false,updatable=false)
    private EmployeeDetails EmployeeDetails;
	
	public EmployeeProject() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public EmployeeProject(int projectid, long empId, String designation, String companyName, int startDateYear,
			int endDateYear, String summary, String project) {
		super();
		this.projectid = projectid;
		this.empId = empId;
		Designation = designation;
		this.companyName = companyName;
		this.startDateYear = startDateYear;
		this.endDateYear = endDateYear;
		this.summary = summary;
		this.project = project;
	}



	public int getProjectid() {
		return projectid;
	}

	public void setProjectid(int projectid) {
		this.projectid = projectid;
	}

	public long getEmpId() {
		return empId;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getStartDateYear() {
		return startDateYear;
	}

	public void setStartDateYear(int startDateYear) {
		this.startDateYear = startDateYear;
	}

	public int getEndDateYear() {
		return endDateYear;
	}

	public void setEndDateYear(int endDateYear) {
		this.endDateYear = endDateYear;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}
	
}
