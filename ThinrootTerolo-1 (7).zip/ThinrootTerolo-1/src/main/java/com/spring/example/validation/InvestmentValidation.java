package com.spring.example.validation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.spring.example.model.Investment;

@Component
public class InvestmentValidation {

public List<Error> validateCreateInvestmentRequest(Investment investment) {
		
		List<Error> errors = new ArrayList<>();
		
		// id
		if(investment.getPurpose()==null) {
       	 Error error = new Error(" Purpose is null");
            errors.add(error);
       }
		if(investment.getAmount()==0) {
	       	 Error error = new Error(" Amount is null");
	            errors.add(error);
	       }
		if(investment.getPayment_Method()==0) {
	       	 Error error = new Error("Payment_Method is null");
	            errors.add(error);
	       }
		if(investment.getCurrency()==null) {
	       	 Error error = new Error(" Currency is null");
	            errors.add(error);
	       }
		if(investment.getCompany()==null) {
	       	 Error error = new Error(" Company is null");
	            errors.add(error);
	       }
		if(investment.getCountry()==null) {
	       	 Error error = new Error(" Country is null");
	            errors.add(error);
	       }
		if(investment.getState()==null) {
	       	 Error error = new Error(" State is null");
	            errors.add(error);
	       }
		if(investment.getBranch()==null) {
	       	 Error error = new Error(" Branch is null");
	            errors.add(error);
	       }
		if(investment.getDescription()==null) {
	       	 Error error = new Error("Description is null");
	            errors.add(error);
	       }
		return errors;
}
}
