package com.spring.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.example.Exception.BadRequestException;
import com.spring.example.model.EducationalDetails;
import com.spring.example.service.EducationalDetailsService;

@RestController
public class EducationalDetailsController {

	@Autowired
	public EducationalDetailsService educationalDetailsService;
	
	@PostMapping("/AddEdu")
	public @ResponseBody ResponseEntity<?> createEducation(@RequestBody EducationalDetails educationDetails ) {
		
		try {
			
			educationalDetailsService.Save(educationDetails);
			return new ResponseEntity<>("successfully created",HttpStatus.OK);
			
		}
		catch(BadRequestException e) {
			 return new ResponseEntity<>("you are trying to add null value",HttpStatus.BAD_REQUEST);
		}
	
	}
	
	@PostMapping("/AddEducation")
	public @ResponseBody ResponseEntity<?> SaveEducation(@RequestParam("college") String college,@RequestParam("qualification") String qualification,
		   @RequestParam("startYear") int startYear,@RequestParam("endYear") int endYear,@RequestParam("summary") String summary,
		   @RequestParam("scl") String scl,@RequestParam("grade") String grade,@RequestParam("sclsummary") String sclsummary,
		   @RequestParam("sclstartYear") int sclstartYear,@RequestParam("sclendYear") int sclendYear,@RequestParam("empId") long empId){
		
		EducationalDetails details = new EducationalDetails();
		details.setCollege(college);
		details.setEmpId(empId);
		details.setEndYear(sclendYear);
		details.setGrade(grade);
		details.setQualification(qualification);
		details.setScl(sclsummary);
		details.setSclendYear(sclendYear);
		details.setSclstartYear(sclstartYear);
		details.setSclsummary(sclsummary);
		details.setStartYear(startYear);
		details.setSummary(sclsummary);
		educationalDetailsService.Save(details);
		return new ResponseEntity<>("success",HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/listEduAll",method=RequestMethod.GET)
	public List<EducationalDetails> listAll()
	{
		if(educationalDetailsService.listAll()==null)
		{
			throw new NullPointerException("No Emp Project were found");
		}
		System.out.println("getting records");
		
		return educationalDetailsService.listAll();
	}
	
	@RequestMapping(value = "/deleteEduAll",method=RequestMethod.DELETE)
	public String deleteAll()
	{
		educationalDetailsService.delete();
		return "all records deleted successfully";
	}
	
	@RequestMapping(value = "/updateEdu",method=RequestMethod.PUT)
	public @ResponseBody ResponseEntity<?> updateProject(@RequestBody EducationalDetails details, @RequestParam int edid ) {
		educationalDetailsService.update(details,edid);
		
		System.out.println(details+""+edid);
			return new ResponseEntity<>("updated successfully",HttpStatus.OK);			
			
		}	
	
	//get single  details
		@RequestMapping(value = "/getEdu",method=RequestMethod.GET)
		public EducationalDetails getByProjectId(@RequestParam int edid) {
			System.out.println("getting record!!!!");
			return educationalDetailsService.findByEmpId(edid)
				.orElseThrow(()-> new UsernameNotFoundException("business Does not exist wit the id   "+edid));
		}
		
		

		//delete single  details
		@DeleteMapping("/deleteEdu")
		public ResponseEntity<?> delete(@RequestParam int edid) {
			Optional<EducationalDetails> details=educationalDetailsService.findByEmpId(edid);
			if(details.isPresent())
			{
				educationalDetailsService.deleteByempId(edid);
			return new ResponseEntity<>("deleted succesfully ",HttpStatus.OK);
			}
			else {
			return new ResponseEntity<>("Project not found ",HttpStatus.NOT_FOUND);
			}
		}
}
