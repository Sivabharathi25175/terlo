package com.spring.example.model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Table(name = "EmployeeDetails")
@Entity
public class EmployeeDetails {

	@Id
	@Column(name="emp_id",unique=true,nullable=false)
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private long empId;
	
	@Column(name="first_name",nullable=false)
	private String firstName;
	private String lastName;
	private String experince;
	private String info;	
	private String mobileNumber;
	private String mailId;
	private String skypeId;
	@Column(length=1000)
	private byte[] photo;
	private String Date_of_Birth;
	
	private String Blood_Group;
	private String Gender;
	private String language;

	
	private String Designation;
	private String Company;
	private String Tools;
	private String skill;
	private String Role;
	private String Abilities;
	
	public EmployeeDetails() {
		super();
	}

	public EmployeeDetails(long empId, String firstName, String lastName, String experince, String info,
			String mobileNumber, String mailId, String skypeId, byte[] photo, String date_of_Birth, String blood_Group,
			String gender, String language, String designation, String company, String tools, String skill, String role,
			String abilities) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.experince = experince;
		this.info = info;
		this.mobileNumber = mobileNumber;
		this.mailId = mailId;
		this.skypeId = skypeId;
		this.photo = photo;
		Date_of_Birth = date_of_Birth;
		Blood_Group = blood_Group;
		Gender = gender;
		this.language = language;
		Designation = designation;
		Company = company;
		Tools = tools;
		this.skill = skill;
		Role = role;
		Abilities = abilities;
	}

	public long getEmpId() {
		return empId;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getExperince() {
		return experince;
	}

	public void setExperince(String experince) {
		this.experince = experince;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getSkypeId() {
		return skypeId;
	}

	public void setSkypeId(String skypeId) {
		this.skypeId = skypeId;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public String getDate_of_Birth() {
		return Date_of_Birth;
	}

	public void setDate_of_Birth(String date_of_Birth) {
		Date_of_Birth = date_of_Birth;
	}

	public String getBlood_Group() {
		return Blood_Group;
	}

	public void setBlood_Group(String blood_Group) {
		Blood_Group = blood_Group;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getCompany() {
		return Company;
	}

	public void setCompany(String company) {
		Company = company;
	}

	public String getTools() {
		return Tools;
	}

	public void setTools(String tools) {
		Tools = tools;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public String getRole() {
		return Role;
	}

	public void setRole(String role) {
		Role = role;
	}

	public String getAbilities() {
		return Abilities;
	}

	public void setAbilities(String abilities) {
		Abilities = abilities;
	}

	
	@OneToMany(mappedBy = "EmployeeDetails", cascade=CascadeType.ALL, orphanRemoval = true)
    private Set<EmployeeProject> EmployeeProject = new HashSet<EmployeeProject>();
	
	@OneToMany(mappedBy = "EmployeeDetails", cascade=CascadeType.ALL, orphanRemoval = true)
    private Set<EducationalDetails> EducationalDetails = new HashSet<EducationalDetails>();

	public Set<EmployeeProject> getEmployeeProject() {
		return EmployeeProject;
	}
	public void setEmployeeProject(Set<EmployeeProject> employeeProject) {
		EmployeeProject = employeeProject;
	}
	public Set<EducationalDetails> getEducationalDetails() {
		return EducationalDetails;
	}
	public void setEducationalDetails(Set<EducationalDetails> educationalDetails) {
		EducationalDetails = educationalDetails;
	}
	
	@Override
	public String toString() {
		return "EmployeeDetailsModule [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", experince=" + experince + ", info=" + info + ", mobileNumber=" + mobileNumber + ", mailId="
				+ mailId + ", skypeId=" + skypeId + ", photo=" + Arrays.toString(photo) + ", Date_of_Birth="
				+ Date_of_Birth + ", Blood_Group=" + Blood_Group + ", Gender=" + Gender + ", language=" + language
				+ ", Designation=" + Designation + ", Company=" + Company + ", Tools=" + Tools + ", skill=" + skill
				+ ", Role=" + Role + ", Abilities=" + Abilities + "]";
	}
	
	
}
