package com.spring.example.model;

public class InvestmentSearchCriteria {

	private long amount;
	private long payment_Method;
	private String currency;
	private String company;
	private String country;
	private String state;
	
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public long getPayment_Method() {
		return payment_Method;
	}
	public void setPayment_Method(long payment_Method) {
		this.payment_Method = payment_Method;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
}
