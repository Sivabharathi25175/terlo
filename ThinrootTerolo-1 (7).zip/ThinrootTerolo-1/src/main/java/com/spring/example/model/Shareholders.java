package com.spring.example.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Shareholders {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int shareholdersId;
	private String shareholder;
	private Long businessid;
	
	public Shareholders() {
		super();
	}

	public Shareholders(int shareholdersId, String shareholder, Long businessid) {
		super();
		this.shareholdersId = shareholdersId;
		this.shareholder = shareholder;
		this.businessid = businessid;
	}



	public int getShareholdersId() {
		return shareholdersId;
	}

	public void setShareholdersId(int shareholdersId) {
		this.shareholdersId = shareholdersId;
	}

	public String getShareholder() {
		return shareholder;
	}

	public void setShareholder(String shareholder) {
		this.shareholder = shareholder;
	}

	public Long getBusinessid() {
		return businessid;
	}


	public void setBusinessid(Long businessid) {
		this.businessid = businessid;
	}

	
	
}
