package com.spring.example.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.spring.example.model.Investment;
import com.spring.example.model.InvestmentPage;
import com.spring.example.model.InvestmentSearchCriteria;

@Repository
public class InvestmentCriteriaRepository {

	private final EntityManager entityManager;
    private final CriteriaBuilder criteriaBuilder;
    
    public InvestmentCriteriaRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
        this.criteriaBuilder = entityManager.getCriteriaBuilder();
    }

	public Page<Investment> findAllWithFilters(InvestmentPage investmentPage,
			InvestmentSearchCriteria investmentSearchCriteria) {
		CriteriaQuery<Investment> criteriaQuery = criteriaBuilder.createQuery(Investment.class);
        Root<Investment> InvestmentRoot = criteriaQuery.from(Investment.class);
        Predicate predicate = getPredicate(investmentSearchCriteria, InvestmentRoot);
        criteriaQuery.where(predicate);
        setOrder(investmentPage, criteriaQuery, InvestmentRoot);

        TypedQuery<Investment> typedQuery = entityManager.createQuery(criteriaQuery);
        typedQuery.setFirstResult(investmentPage.getPageNumber() * investmentPage.getPageSize());
        typedQuery.setMaxResults(investmentPage.getPageSize());

        Pageable pageable = getPageable(investmentPage);

        long employeesCount = getInvestmentCount(predicate);

        return new PageImpl<>(typedQuery.getResultList(), pageable, employeesCount);

	}

	private Predicate getPredicate(InvestmentSearchCriteria investmentSearchCriteria, Root<Investment> investmentRoot) {
		
		  List<Predicate> predicates = new ArrayList<>();
		  if(Objects.nonNull(investmentSearchCriteria.getCompany())){
	            predicates.add(
	                    criteriaBuilder.like(investmentRoot.get("company"),
	                            "%" + investmentSearchCriteria.getCompany() + "%")
	            );
	        }
		  if(Objects.nonNull(investmentSearchCriteria.getAmount())){
	            predicates.add(
	                    criteriaBuilder.like(investmentRoot.get("amount"),
	                            "%" + investmentSearchCriteria.getAmount() + "%")
	            );
	        }
		  if(Objects.nonNull(investmentSearchCriteria.getPayment_Method())){
	            predicates.add(
	                    criteriaBuilder.like(investmentRoot.get("payment_Method"),
	                            "%" + investmentSearchCriteria.getPayment_Method() + "%")
	            );
	        }
		  if(Objects.nonNull(investmentSearchCriteria.getCurrency())){
	            predicates.add(
	                    criteriaBuilder.like(investmentRoot.get("currency"),
	                            "%" + investmentSearchCriteria.getCurrency() + "%")
	            );
	        }
		  if(Objects.nonNull(investmentSearchCriteria.getState())){
	            predicates.add(
	                    criteriaBuilder.like(investmentRoot.get("state"),
	                            "%" + investmentSearchCriteria.getState() + "%")
	            );
	        }
		  if(Objects.nonNull(investmentSearchCriteria.getCountry())){
	            predicates.add(
	                    criteriaBuilder.like(investmentRoot.get("country"),
	                            "%" + investmentSearchCriteria.getCountry() + "%")
	            );
	        }
		  return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
	}

	private void setOrder(InvestmentPage investmentPage, CriteriaQuery<Investment> criteriaQuery,
			Root<Investment> investmentRoot) {
		   if(investmentPage.getSortDirection().equals(Sort.Direction.ASC)){
	            criteriaQuery.orderBy(criteriaBuilder.asc(investmentRoot.get(investmentPage.getSortBy())));
	        } 
		   else {
	            criteriaQuery.orderBy(criteriaBuilder.desc(investmentRoot.get(investmentPage.getSortBy())));
	        }
		
	}
	
	private Pageable getPageable(InvestmentPage investmentPage) {
		Sort sort = Sort.by(investmentPage.getSortDirection(), investmentPage.getSortBy());
        return PageRequest.of(investmentPage.getPageNumber(),investmentPage.getPageSize(), sort);
		
	}
	
	private long getInvestmentCount(Predicate predicate) {
		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        Root<Investment> countRoot = countQuery.from(Investment.class);
        countQuery.select(criteriaBuilder.count(countRoot)).where(predicate);
        return entityManager.createQuery(countQuery).getSingleResult();
	}
}
