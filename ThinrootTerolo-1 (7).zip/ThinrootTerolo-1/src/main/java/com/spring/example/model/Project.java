package com.spring.example.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Project {

	@Id
	private int projectrefId;
	private String project;
	
	private int projectid;
	
	public Project() {
		super();
	}

	public Project(int projectrefId, String project, int projectid) {
		super();
		this.projectrefId = projectrefId;
		this.project = project;
		this.projectid = projectid;
	}

	public int getProjectrefId() {
		return projectrefId;
	}

	public void setProjectrefId(int projectrefId) {
		this.projectrefId = projectrefId;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public int getProjectid() {
		return projectid;
	}

	public void setProjectid(int projectid) {
		this.projectid = projectid;
	}
	
}
