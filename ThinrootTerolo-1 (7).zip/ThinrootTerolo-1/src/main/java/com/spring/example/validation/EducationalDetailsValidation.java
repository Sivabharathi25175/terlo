package com.spring.example.validation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.spring.example.model.EducationalDetails;

@Component
public class EducationalDetailsValidation {

public List<Error> validateCreateEducationRequest(EducationalDetails education) {
		
		List<Error> errors = new ArrayList<>();
		
		 if(education.getCollege()==null) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		 if(education.getQualification()==null) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		 if(education.getStartYear()==0) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		 if(education.getEndYear()==0) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		 if(education.getSummary()==null) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		 if(education.getScl()==null) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		 if(education.getSclstartYear()==0) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		 if(education.getSclendYear()==0) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		 if(education.getSclsummary()==null) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		 if(education.getGrade()==null) {
        	 Error error = new Error("FirstName is null");
             errors.add(error);
        }
		return errors;
		
}
}
