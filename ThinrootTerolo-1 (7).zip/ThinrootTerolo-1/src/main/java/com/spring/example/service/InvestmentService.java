package com.spring.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.spring.example.Exception.BadRequestException;
import com.spring.example.model.Investment;
import com.spring.example.model.InvestmentPage;
import com.spring.example.model.InvestmentSearchCriteria;
import com.spring.example.repository.InvestmentCriteriaRepository;
import com.spring.example.repository.InvestmentRepository;
import com.spring.example.validation.InvestmentValidation;

@Service
public class InvestmentService {

	@Autowired
	private InvestmentRepository investmentRepository;
	
	@Autowired
	private InvestmentValidation investmentValidation;
	
	@Autowired
	private InvestmentCriteriaRepository investmentCriteriaRepository;
	
	//create
		public void save(Investment Investment) {
		
			List<Error> errors =investmentValidation.validateCreateInvestmentRequest(Investment);
			 
			//if not success
			  if(errors.size() > 0) { 
				   throw new BadRequestException("you have missed the some values ",errors); 
			   }
			   
			  investmentRepository.save(Investment);
		}
		
		// get all
				public List<Investment> listAll()
				{
					return (List<Investment>) investmentRepository.findAll();
					
				}
				
				//delete by id
				public void deleteByInvestmentid(long investmentid) {
					investmentRepository.deleteByInvestmentid(investmentid);
				}
				
				//getA single employee details
				public Optional<Investment> findByInvestmentid(long investmentid) {
					
					return investmentRepository.findByInvestmentid(investmentid);
				}
				
				// update 
				public Investment update(long investmentid, byte[] invoice, String purpose, long amount, long payment_Method,
						String currency, String company, String country, String state, String branch, String description)
				{
					
					Investment inv=investmentRepository.findById(investmentid).get();
					inv.setInvestmentid(investmentid);
					inv.setAmount(amount);
					inv.setBranch(branch);
					inv.setCompany(company);
					inv.setCountry(country);
					inv.setCurrency(currency);
					inv.setDescription(description);
					inv.setInvoice(invoice);
					inv.setPayment_Method(payment_Method);
					inv.setPurpose(purpose);
					inv.setState(state);
					return investmentRepository.save(inv);
				}
				
				//deleteAll
				public void delete()
				{
					investmentRepository.deleteAll();
				}
				
				// search
				public List<Investment> findByCompanyOrCurrencyOrStateOrCountry(String company, String currency,
						String state,String country) {
					return investmentRepository.findByCompanyOrCurrencyOrStateOrCountry(company, currency,state,country);
				}
				
				public Page<Investment> getEmployees(InvestmentPage investmentPage,
						InvestmentSearchCriteria investmentSearchCriteria){
					return investmentCriteriaRepository.findAllWithFilters(investmentPage, investmentSearchCriteria);
}
}
