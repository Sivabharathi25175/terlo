package com.spring.example.controller;

import javax.naming.NameNotFoundException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.example.model.DAOUser;
import com.spring.example.service.UserlistService;

public class ResourceController {
	@Autowired
	private UserlistService userService;
	
	@RequestMapping("/welcome")
	public String getUser() {
		return "Hello User";
	}
	
	@RequestMapping("/home")
	public String getAdmin() {
		return "Hello Admin";
	}
	

	// to get the user details of particular user
	@GetMapping("/getUserDetails")
	public DAOUser getDetails(@RequestParam String username) throws  NameNotFoundException {
		DAOUser daouser=userService.getUser(username);
		if(!(daouser.getUsername()).equals(username))
		{
			throw new NameNotFoundException(username);
		}
		return userService.getUser(username);	   
	}
	
	// update user
	@PutMapping("/updateUser")
	public @ResponseBody ResponseEntity<?> updateUser(@RequestBody DAOUser user,@RequestParam String username) {
		userService.update(user, username);
		return new ResponseEntity<>("updated successfully",HttpStatus.ACCEPTED);
	}
	
	// delete user
	@Transactional
	@GetMapping("deleteUser")
	public String deleteuser(@RequestParam String username) throws NameNotFoundException {
		DAOUser daouser=userService.getUser(username);
		if(!(daouser.getUsername()).equals(username))
		{
			throw new NameNotFoundException("username does not exist "+username);
		}
		return userService.deleteByuser(username);		   
	}
}
