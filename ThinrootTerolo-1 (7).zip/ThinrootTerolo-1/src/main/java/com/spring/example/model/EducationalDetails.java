package com.spring.example.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class EducationalDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int edid;
	private String college;
	private String qualification;
	private int startYear;
	private int endYear;
	private String summary;
	
	private String scl;
	private String grade;
	private String sclsummary;
	private int sclstartYear;
	private int sclendYear;
	@Column(name="emp_id")
	private long empId;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(foreignKey = @javax.persistence.ForeignKey(name = "fk1_emp_id"), name="emp_id", referencedColumnName = "emp_id", columnDefinition = "long",insertable=false,updatable=false)
    private EmployeeDetails EmployeeDetails;
	
	public EducationalDetails() {
		super();
	}


	public EducationalDetails(int edid, String college, String qualification, int startYear, int endYear,
			String summary, String scl, String grade, String sclsummary, int sclstartYear, int sclendYear, long empId) {
		super();
		this.edid = edid;
		this.college = college;
		this.qualification = qualification;
		this.startYear = startYear;
		this.endYear = endYear;
		this.summary = summary;
		this.scl = scl;
		this.grade = grade;
		this.sclsummary = sclsummary;
		this.sclstartYear = sclstartYear;
		this.sclendYear = sclendYear;
		this.empId = empId;
	}


	public int getEdid() {
		return edid;
	}



	public void setEdid(int edid) {
		this.edid = edid;
	}



	public String getCollege() {
		return college;
	}



	public void setCollege(String college) {
		this.college = college;
	}



	public String getQualification() {
		return qualification;
	}



	public void setQualification(String qualification) {
		this.qualification = qualification;
	}



	public int getStartYear() {
		return startYear;
	}



	public void setStartYear(int startYear) {
		this.startYear = startYear;
	}



	public int getEndYear() {
		return endYear;
	}



	public void setEndYear(int endYear) {
		this.endYear = endYear;
	}



	public String getSummary() {
		return summary;
	}



	public void setSummary(String summary) {
		this.summary = summary;
	}



	public String getScl() {
		return scl;
	}



	public void setScl(String scl) {
		this.scl = scl;
	}



	public String getGrade() {
		return grade;
	}



	public void setGrade(String grade) {
		this.grade = grade;
	}



	public String getSclsummary() {
		return sclsummary;
	}



	public void setSclsummary(String sclsummary) {
		this.sclsummary = sclsummary;
	}



	public int getSclstartYear() {
		return sclstartYear;
	}



	public void setSclstartYear(int sclstartYear) {
		this.sclstartYear = sclstartYear;
	}



	public int getSclendYear() {
		return sclendYear;
	}



	public void setSclendYear(int sclendYear) {
		this.sclendYear = sclendYear;
	}



	public long getEmpId() {
		return empId;
	}



	public void setEmpId(long empId) {
		this.empId = empId;
	}

	
	@Override
	public String toString() {
		return "EducationalDetails [edid=" + edid + ", college=" + college + ", qualification=" + qualification
				+ ", startYear=" + startYear + ", endYear=" + endYear + ", summary=" + summary + ", scl=" + scl
				+ ", grade=" + grade + ", sclsummary=" + sclsummary + ", sclstartYear=" + sclstartYear + ", sclendYear="
				+ sclendYear + ", empId=" + empId + "]";
	}
}
