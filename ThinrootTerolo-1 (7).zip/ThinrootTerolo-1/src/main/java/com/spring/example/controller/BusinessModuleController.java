package com.spring.example.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.spring.example.model.Business;
import com.spring.example.model.BusinessPage;
import com.spring.example.model.BusinessSearchCriteria;
import com.spring.example.model.Shareholders;
import com.spring.example.service.BusinessService;

@RestController
public class BusinessModuleController {

	@Autowired
	private BusinessService businessOpService;
	
	@Value("${upoadDir}")
	private String uploadFolder;
	
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@RequestMapping(value = "/AddDetails",method=RequestMethod.POST)
	public @ResponseBody ResponseEntity<?> createBusiness(@RequestParam("businessid")long businessid,
		   @RequestParam("companyname") String companyname,@RequestParam("gstno") String gstno,@RequestParam("category") String category,
		   @RequestParam("type") String type,@RequestParam("paidupcapital") int paidupcapital,@RequestParam("authorisedcapital") int authorisedcapital,
		   @RequestParam("ceo") String ceo,@RequestParam("employee") int employee,@RequestParam("shareholder") List<Shareholders> shareholder,
		   @RequestParam("address1")String address1,@RequestParam("address2") String address2,@RequestParam("compname") String compname,
		   @RequestParam("country") String country,@RequestParam("state") String state,Model model, HttpServletRequest request,
		   final @RequestParam("photo") MultipartFile imagefile,final @RequestParam("file") MultipartFile docfile){
		
		try {
			String uploadDirectory=request.getServletContext().getRealPath(uploadFolder);
			log.info("uploadDirectory::"+uploadDirectory);
			String fileName=imagefile.getOriginalFilename();
			String filepath=Paths.get(uploadDirectory, fileName).toString();
			log.info("Filename:"+imagefile.getOriginalFilename());
			if(fileName==null || fileName.contains(".."))
			{
				model.addAttribute("invalid","Sorry! filename conatains invalid path"+fileName);
				return new ResponseEntity<>("Sorry! filename contains invalid path"+fileName,HttpStatus.BAD_REQUEST);
			}
			try {
				File dir = new File(uploadDirectory);
				if (!dir.exists()) {
					log.info("Folder Created");
					dir.mkdirs();
				}
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filepath)));
				stream.write(fileName.getBytes());
				stream.close();
			}
			catch (Exception e) {
				log.info("in catch");
				e.printStackTrace();
			}
			byte[] imageData = imagefile.getBytes();
			byte[] docData = docfile.getBytes();
			
			Business busi = new Business();
			busi.setBusinessid(businessid);
			busi.setAddress1(address1);
			busi.setAddress2(address2);
			busi.setAuthorisedcapital(authorisedcapital);
			busi.setCategory(category);
			busi.setCeo(ceo);
			busi.setCompanyname(companyname);
			busi.setCompname(compname);
			busi.setCountry(country);
			busi.setEmployee(employee);
			busi.setFile(docData);
			busi.setGstno(gstno);
			busi.setPaidupcapital(paidupcapital);
			busi.setPhoto(imageData);
			busi.setShareholder(shareholder);
			busi.setState(state);
			busi.setType(type);
			
			businessOpService.Save(busi);
			
			return new ResponseEntity<>("success",HttpStatus.OK);
			
	}
		catch (Exception e) {
			e.printStackTrace();
			log.info("Exception: " + e);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/listAll",method=RequestMethod.GET)
	public List<Business> listAll()
	{
		if(businessOpService.listAll()==null)
		{
			throw new NullPointerException("No Business were found");
		}
		System.out.println("getting records");
		
		return businessOpService.listAll();
	}
	
	@RequestMapping(value = "/deleteAll",method=RequestMethod.DELETE)
	public String deleteAll()
	{
		businessOpService.delete();
		return "all records deleted successfully";
	}
	
	//get single Business details
	@RequestMapping(value = "/getBusiness",method=RequestMethod.GET)
	public Business getBusiness(@RequestParam long businessid) {
		System.out.println("getting record!!!!");
		return businessOpService.findByBusinessid(businessid)
			.orElseThrow(()-> new UsernameNotFoundException("business Does not exist wit the id   "+businessid));
	}
	

	//delete single Business details
	@RequestMapping(value = "/deletebusiness",method=RequestMethod.DELETE)
	public ResponseEntity<?> delete(@RequestParam long businessid) {
		Optional<Business> details=businessOpService.findByBusinessid(businessid);
		if(details.isPresent())
		{
			businessOpService.deleteByBusinessid(businessid);
		return new ResponseEntity<>("deleted succesfully ",HttpStatus.OK);
		}
		else {
		return new ResponseEntity<>("employee not found ",HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value = "/update",method=RequestMethod.PUT)
	public @ResponseBody ResponseEntity<?> updatebusiness(@RequestParam("businessid")long businessid,
			   @RequestParam("companyname") String companyname,@RequestParam("gstno") String gstno,@RequestParam("category") String category,
			   @RequestParam("type") String type,@RequestParam("paidupcapital") int paidupcapital,@RequestParam("authorisedcapital") int authorisedcapital,
			   @RequestParam("ceo") String ceo,@RequestParam("employee") int employee,@RequestParam("shareholder") List<Shareholders> shareholder,
			   @RequestParam("address1")String address1,@RequestParam("address2") String address2,@RequestParam("compname") String compname,
			   @RequestParam("country") String country,@RequestParam("state") String state,Model model, HttpServletRequest request,
			   final @RequestParam("photo") MultipartFile imagefile,final @RequestParam("file") MultipartFile docfile){
		
		try {
			String uploadDirectory=request.getServletContext().getRealPath(uploadFolder);
			log.info("uploadDirectory::"+uploadDirectory);
			String fileName=imagefile.getOriginalFilename();
			String filepath=Paths.get(uploadDirectory, fileName).toString();
			log.info("Filename:"+imagefile.getOriginalFilename());
			if(fileName==null || fileName.contains(".."))
			{
				model.addAttribute("invalid","Sorry! filename conatains invalid path"+fileName);
				return new ResponseEntity<>("Sorry! filename contains invalid path"+fileName,HttpStatus.BAD_REQUEST);
			}
			try {
				File dir = new File(uploadDirectory);
				if (!dir.exists()) {
					log.info("Folder Created");
					dir.mkdirs();
				}
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filepath)));
				stream.write(fileName.getBytes());
				stream.close();
			}
			catch (Exception e) {
				log.info("in catch");
				e.printStackTrace();
			}
			byte[] imageData = imagefile.getBytes();
			byte[] docData=docfile.getBytes();
			
			Business business = new Business();
			business.setBusinessid(businessid);
			business.setAddress1(address1);
			business.setAddress2(address2);
			business.setAuthorisedcapital(authorisedcapital);
			business.setCategory(category);
			business.setCeo(ceo);
			business.setCompanyname(companyname);
			business.setCompname(compname);
			business.setCountry(country);
			business.setEmployee(employee);
			business.setFile(docData);
			business.setGstno(gstno);
			business.setPaidupcapital(paidupcapital);
			business.setPhoto(imageData);
			business.setShareholder(shareholder);
			business.setState(state);
			business.setType(type);
			
			businessOpService.update(businessid, imageData, companyname, gstno, category, type, paidupcapital,
					authorisedcapital, ceo, employee, docData, shareholder, address1, address2, compname, country, state);
			
			return new ResponseEntity<>("success",HttpStatus.OK);
			
	}
		catch (Exception e) {
			e.printStackTrace();
			log.info("Exception: " + e);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	//for filtering by email,mobile number,name,name
	@RequestMapping(value = "/filters",method=RequestMethod.GET)
	public ResponseEntity<List<Business>> getByCompanynameOrCategoryOrTypeOrStateOrCountry(@RequestParam(required=false) String companyname,@RequestParam(required=false) String category,@RequestParam(required=false) String type,@RequestParam(required=false) String state, @RequestParam(required=false) String country) {
		return new ResponseEntity<List<Business>>(businessOpService.findByCompanynameOrCategoryOrTypeOrStateOrCountry(companyname,category,
				 type, state, country), HttpStatus.OK);
	}
	

	@RequestMapping(value = "/sortingbusiness",method=RequestMethod.GET)
	public ResponseEntity<Page<Business>> getEmployees(BusinessPage businessPage,
			BusinessSearchCriteria businessSearchCriteria){
	    return new ResponseEntity<>(businessOpService.getBusiness(businessPage, businessSearchCriteria),
	            HttpStatus.OK);
	    
	}
}
