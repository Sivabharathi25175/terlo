package com.spring.example.validation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.spring.example.model.Business;

@Component
public class BusinessValidation {
	
	public List<Error> validateCreateBusinessRequest(Business business) {
		
		List<Error> errors = new ArrayList<>();
		
		// id
        
        if(business.getCompname()==null) {
        	 Error error = new Error("Company name is null");
             errors.add(error);
        }
        
        if(business.getGstno()==null) {
       	 Error error = new Error("GST NO is null");
            errors.add(error);
       }
        
        if(business.getCategory()==null) {
          	 Error error = new Error("Category is null");
               errors.add(error);
          }
        
        if(business.getType()==null) {
         	 Error error = new Error("Type is null");
              errors.add(error);
         }
        
        if(business.getAuthorisedcapital() == 0) {
         	 Error error = new Error("Authorised capital is null");
              errors.add(error);
         }
        
        if(business.getPaidupcapital()== 0) {
         	 Error error = new Error("Paidup capital is null");
              errors.add(error);
         }
        
        if(business.getCeo()== null) {
        	 Error error = new Error("Ceo is null");
             errors.add(error);
        }
        
        if(business.getEmployee()== 0) {
        	 Error error = new Error("No of Employee  is null");
             errors.add(error);
        }
        
        if(business.getAddress1()== null) {
        	 Error error = new Error("Address line 1 is null");
             errors.add(error);
        }
        
        if(business.getAddress2()== null) {
        	 Error error = new Error("Address line 2 is null");
             errors.add(error);
        }
        
        if(business.getCompname()== null) {
        	 Error error = new Error("Company Name is null");
             errors.add(error);
        }
        
        if(business.getCountry()== null) {
        	 Error error = new Error("Country is null");
             errors.add(error);
        }
        
        if(business.getShareholder()== null) {
          	 Error error = new Error("Shareholder is null");
               errors.add(error);
          }
        
        if(business.getState()== null) {
       	 Error error = new Error("State is null");
            errors.add(error);
       }
        
		return errors;
		
	}
}
