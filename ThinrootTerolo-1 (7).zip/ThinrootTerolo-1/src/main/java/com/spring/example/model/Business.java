package com.spring.example.model;


import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Table(name = "BusinessDetails")
@Entity
public class Business {

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private long businessid;
	@Column(length=1000)
	private byte[] photo;
	private String companyname;
	private String gstno;
	private String category;
	private String type;
	private int paidupcapital;
	private int authorisedcapital;
	private String ceo;
	private int employee;
	@Column(length = 1000)
	private byte[] file;
	@OneToMany
    private List<Shareholders> shareholder;
	private String address1;
	private String address2;
	private String compname;
	private String country;
	private String state;
	
	
	public Business() {
		super();
		
	}

	public Business(long businessid, byte[] photo, String companyname, String gstno, String category, String type,
			int paidupcapital, int authorisedcapital, String ceo, int employee, byte[] file,
			List<Shareholders> shareholder, String address1, String address2, String compname, String country,
			String state) {
		super();
		this.businessid = businessid;
		this.photo = photo;
		this.companyname = companyname;
		this.gstno = gstno;
		this.category = category;
		this.type = type;
		this.paidupcapital = paidupcapital;
		this.authorisedcapital = authorisedcapital;
		this.ceo = ceo;
		this.employee = employee;
		this.file = file;
		this.shareholder = shareholder;
		this.address1 = address1;
		this.address2 = address2;
		this.compname = compname;
		this.country = country;
		this.state = state;
	}


	public long getBusinessid() {
		return businessid;
	}


	public void setBusinessid(long businessid) {
		this.businessid = businessid;
	}


	public byte[] getPhoto() {
		return photo;
	}


	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}


	public String getCompanyname() {
		return companyname;
	}


	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}


	public String getGstno() {
		return gstno;
	}


	public void setGstno(String gstno) {
		this.gstno = gstno;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public int getPaidupcapital() {
		return paidupcapital;
	}


	public void setPaidupcapital(int paidupcapital) {
		this.paidupcapital = paidupcapital;
	}


	public int getAuthorisedcapital() {
		return authorisedcapital;
	}


	public void setAuthorisedcapital(int authorisedcapital) {
		this.authorisedcapital = authorisedcapital;
	}


	public String getCeo() {
		return ceo;
	}


	public void setCeo(String ceo) {
		this.ceo = ceo;
	}


	public int getEmployee() {
		return employee;
	}


	public void setEmployee(int employee) {
		this.employee = employee;
	}


	public byte[] getFile() {
		return file;
	}


	public void setFile(byte[] file) {
		this.file = file;
	}

	public List<Shareholders> getShareholder() {
		return shareholder;
	}

	public void setShareholder(List<Shareholders> shareholder) {
		this.shareholder = shareholder;
	}

	public String getAddress1() {
		return address1;
	}


	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	public String getAddress2() {
		return address2;
	}


	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	public String getCompname() {
		return compname;
	}


	public void setCompname(String compname) {
		this.compname = compname;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	@Override
	public String toString() {
		return "Business [businessid=" + businessid + ", phote=" + Arrays.toString(photo) + ", companyname="
				+ companyname + ", gstno=" + gstno + ", category=" + category + ", type=" + type + ", paidupcapital="
				+ paidupcapital + ", authorisedcapital=" + authorisedcapital + ", ceo=" + ceo + ", employee=" + employee
				+ ", file=" + Arrays.toString(file) + ", shareholder=" + shareholder + ", address1=" + address1
				+ ", address2=" + address2 + ", compname=" + compname + ", country=" + country + ", state=" + state
				+ "]";
	}

	
}
